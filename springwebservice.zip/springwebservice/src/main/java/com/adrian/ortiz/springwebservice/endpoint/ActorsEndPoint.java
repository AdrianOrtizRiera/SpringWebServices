package com.adrian.ortiz.springwebservice.endpoint;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.adrian.ortiz.gs_ws.ActorType;
import com.adrian.ortiz.gs_ws.GetActorByIdRequest;
import com.adrian.ortiz.gs_ws.GetActorByIdResponse;
import com.adrian.ortiz.springwebservice.dao.entity.ActorEntity;
import com.adrian.ortiz.springwebservice.dao.interfaces.ActorEntityService;

@Endpoint
public class ActorsEndPoint {
	
	public static final String NAMESPACE_URI = "http://adrian.ortiz.com/actors-ws";
	
	private ActorEntityService service;
	
	public ActorsEndPoint() {
		
	}
	
	@Autowired
	public ActorsEndPoint(ActorEntityService service) {
		this.service = service;
	}
	
	@PayloadRoot(namespace=NAMESPACE_URI, localPart="getActorByIdRequest")
	@ResponsePayload
	public GetActorByIdResponse getActorById(@RequestPayload GetActorByIdRequest request) {
		GetActorByIdResponse response = new GetActorByIdResponse();
		ActorEntity actorEntity = service.getEntityById(request.getActorId());
		ActorType actorType = new ActorType();
		BeanUtils.copyProperties(actorEntity, actorType);
		response.setFirstName(actorType.getFirstName());
		response.setLastName(actorEntity.getLast_name());
		return response;
	}
}
