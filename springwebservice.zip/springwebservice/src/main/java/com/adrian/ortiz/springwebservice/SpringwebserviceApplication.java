package com.adrian.ortiz.springwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwebserviceApplication.class, args);
	}

}
